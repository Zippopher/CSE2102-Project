package userInterface;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import Function.Main;
import Function.Review;
import Function.User;

import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminWindow extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 15L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		try {
			AdminWindow dialog = new AdminWindow();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	*/
	/**
	 * Create the dialog.
	 */
	public AdminWindow(NEW_UI newui, User[] users) {
		setBounds(100, 100, 550, 330);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setTitle("OR3 - Administrative Controls");
		
		JList<User> list = new JList<User>(users);
		JScrollPane listScroller = new JScrollPane(list);
		listScroller.setBounds(10, 36, 127, 172);
		contentPanel.add(listScroller);
		
		JLabel lblUserList = new JLabel("User List:");
		lblUserList.setBounds(10, 10, 61, 16);
		contentPanel.add(lblUserList);
		
		JButton btnAdminUser = new JButton("Admin User");
		btnAdminUser.setBounds(10, 250, 120, 29);
		btnAdminUser.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.adminUser(list.getSelectedValue());
				newui.refresh();
				AdminWindow.this.dispose();
			}
		});
		contentPanel.add(btnAdminUser);
		
		JButton btnDeleteUser = new JButton("Delete User");
		btnDeleteUser.setBounds(10, 215, 120, 29);
		btnDeleteUser.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.removeUser(list.getSelectedValue());
				newui.refresh();
				AdminWindow.this.dispose();
			}
		});
		contentPanel.add(btnDeleteUser);
		
		JLabel lblAddRestaurant = new JLabel("Add Restaurant:");
		lblAddRestaurant.setBounds(147, 10, 106, 16);
		contentPanel.add(lblAddRestaurant);
		
		textField = new JTextField();
		textField.setBounds(147, 36, 179, 26);
		contentPanel.add(textField);
		textField.setColumns(10);
		
		JButton btnAddRestaurant = new JButton("Add Restaurant");
		btnAddRestaurant.setBounds(147, 68, 133, 29);
		btnAddRestaurant.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.addRestaurant(textField.getText());
				newui.setList(Main.getRestaurants());
				newui.refresh();
				AdminWindow.this.dispose();
			}
		});
		contentPanel.add(btnAddRestaurant);
		
		JList<Review> revList = new JList<Review>(Main.getHiddenReviews());
		revList.setCellRenderer(new NewListCellRenderer());
		
		JScrollPane listScroller2 = new JScrollPane(revList);
		listScroller2.setBounds(336, 36, 187, 172);
		contentPanel.add(listScroller2);
		
		JLabel lblRevList = new JLabel("Reported Reviews:");
		lblRevList.setBounds(336, 10, 120, 16);
		contentPanel.add(lblRevList);
		
		JButton btnPardonRev = new JButton("Pardon Review");
		btnPardonRev.setBounds(336, 250, 120, 29);
		btnPardonRev.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.hideReview(revList.getSelectedValue(), false);
				newui.refresh();
				AdminWindow.this.dispose();
			}
		});
		contentPanel.add(btnPardonRev);
		
		JButton btnDeleteRev = new JButton("Delete Review");
		btnDeleteRev.setBounds(336, 215, 120, 29);
		btnDeleteRev.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.deleteReview(revList.getSelectedValue());
				newui.refresh();
				AdminWindow.this.dispose();
			}
		});
		contentPanel.add(btnDeleteRev);
	}
	
	private class NewListCellRenderer extends DefaultListCellRenderer {

        /**
		 * 
		 */
		private static final long serialVersionUID = 16L;

		@Override
        public Component getListCellRendererComponent(
                JList list, Object value, int index,
                boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            Review label = (Review) value;
            String author = label.getAuthor().getUsername();
            String rev = label.getReview();
            String labelText = "<html>User: " + author + "<br/>Overall: " + ((Review) value).getOverallRating() + "<br/>Price: " + ((Review) value).getPriceRating() + "<br/>Review: " + rev + "<br/>---------------------------------------";
            setText(labelText);

            return this;
        }

    }
}