package userInterface;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Dimension;
import java.awt.EventQueue;
import javax.swing.ListSelectionModel;

import Function.Main;
import Function.Restaurant;

import javax.swing.JComboBox;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JLabel;
import javax.swing.JFrame;

import java.awt.CardLayout;

public class NEW_UI extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 10L;
	private JTextField Name;
	private String[] type = {"Name", "Rating", "Price"};
	public static JFrame frame;
	static Restaurant[] restList;

	
	public static void main(String[] args, Restaurant[] rests) {
		restList = rests;
		EventQueue.invokeLater(new Runnable() {
			public void run(){
	            frame = new JFrame();
	            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	            frame.getContentPane().add(new NEW_UI());
	            frame.pack();
	            frame.setVisible(true);
	        }
		});
	}
	
	/**
	 * Create the panel.
	 */
	public NEW_UI() {
		setLayout(new CardLayout(0, 0));
		frame.setTitle("OR3 - Review Managment System");

		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(454, 304));
		add(panel, "name_432987060586482");
		panel.setLayout(null);

		Name = new JTextField();
		Name.setBounds(10, 10, 165, 26);
		panel.add(Name);
		Name.setText("Search");
		Name.setColumns(10);


		JButton btnSearch = new JButton("Enter");
		btnSearch.setBounds(185, 10, 76, 29);
		panel.add(btnSearch);

		JLabel lblSearchBy = new JLabel("Search by:");
		lblSearchBy.setBounds(282, 15, 64, 16);
		panel.add(lblSearchBy);

		JComboBox<String> comboBox = new JComboBox<String>(type);
		comboBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
			}
		});
		comboBox.setBounds(348, 11, 96, 27);
		panel.add(comboBox);
		
		//search feature
				btnSearch.addMouseListener(new MouseAdapter() {
					@Override
					public void mousePressed(MouseEvent e) {
						setList(Main.search(Name.getText(), comboBox.getSelectedIndex()));
						
						NEW_UI.this.refresh();
					}
				});
		
		JList<Restaurant> list = new JList<Restaurant>(restList);
		list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		list.setLayoutOrientation(JList.VERTICAL);
		list.setVisibleRowCount(-1);
		JScrollPane listScroller = new JScrollPane(list);
		listScroller.setBounds(10, 48, 292, 205);
		panel.add(listScroller);
		
		
		JButton makeRev = new JButton("New Review");
		makeRev.setBounds(312, 48, 132, 29);
		panel.add(makeRev);
		makeRev.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(list.getSelectedValue() != null){
					ReviewWindow review = new ReviewWindow(NEW_UI.this, list.getSelectedValue(), Main.getCurrentUser());
					review.setVisible(true);
				}
			}
		});
		
		JButton seeRev = new JButton("See Reviews");
		seeRev.setBounds(312, 87, 132, 29);
		panel.add(seeRev);
		seeRev.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if(list.getSelectedValue() != null){
					ReadWindow read = new ReadWindow(NEW_UI.this, list.getSelectedValue(), Main.getCurrentUser());
					read.setVisible(true);
				}
			}
		});
		
		JButton delRest = new JButton("Delete Location");
		delRest.setBounds(312, 126, 132, 29);
		if(Main.getCurrentUser() instanceof Function.Admin)
		{
			panel.add(delRest);
		}
		delRest.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.removeRestaurant(list.getSelectedValue());
				restList = Main.getRestaurants();
				NEW_UI.this.refresh();
			}
		});
		
		JButton adminCont = new JButton("Admin Controls");
		adminCont.setBounds(312, 165, 132, 29);
		if(Main.getCurrentUser() instanceof Function.Admin)
		{
			panel.add(adminCont);
		}
		adminCont.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				AdminWindow adWin = new AdminWindow(NEW_UI.this, Main.getUsers());
				adWin.setVisible(true);
			}
		});
		
		JButton btnSignIn = new JButton("Sign in");
		btnSignIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Login login = new Login(NEW_UI.this);
				login.setVisible(true);
			}
		});
		btnSignIn.setBounds(195, 265, 117, 29);
		panel.add(btnSignIn);
		
		JButton button = new JButton("Sign up");
		button.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Signup signup = new Signup(NEW_UI.this);
				signup.setVisible(true);
			}
		});
		button.setBounds(324, 265, 117, 29);
		panel.add(button);

		JButton signOut = new JButton("Sign Out");
		signOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.verifyUser("anon", "");
				refresh();
			}
		});
		signOut.setBounds(66, 265, 117, 29);
		panel.add(signOut);
		
		WindowListener exitListener = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				Main.saveToFile();
				System.out.println("All Data Saved");
				System.exit(1);
			}
		};
		frame.addWindowListener(exitListener);
		
	}
	
	public void setList(Restaurant[] rests)
	{
		restList = rests;
	}
	
	public void refresh()
	{
		NEW_UI.main(new String[0], restList);
		frame.dispose();
	}
}
