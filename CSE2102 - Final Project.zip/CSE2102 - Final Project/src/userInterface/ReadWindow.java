package userInterface;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Function.Main;
import Function.Restaurant;
import Function.Review;
import Function.User;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class ReadWindow extends JDialog {

	private static final long serialVersionUID = 13L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	/*
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReadWindow frame = new ReadWindow();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/
	/**
	 * Create the frame.
	 */
	public ReadWindow(NEW_UI newui, Restaurant rest, User user) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("OR3 - Review Reader");
		setBounds(100, 100, 450, 385);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblOverallRating = new JLabel("Overall Rating: " + new BigDecimal(String.valueOf(rest.getAvgRate())).setScale(1, BigDecimal.ROUND_HALF_UP));
		lblOverallRating.setBounds(31, 16, 110, 16);
		contentPane.add(lblOverallRating);
		
		JLabel label = new JLabel("Price Rating: " + new BigDecimal(String.valueOf(rest.getAvgPrice())).setScale(1, BigDecimal.ROUND_HALF_UP));
		label.setBounds(224, 16, 1110, 16);
		contentPane.add(label);
		
		String revs = "";
		for(Review r : rest.getReviews())
		{
			revs = revs + r.getAuthor().getUsername() + ":\n" + r.getReview() + "\n\n";
		}
		
		String type;
		if(rest.getIsPosNeg() < 0)
			type = "Negative";
		else if(rest.getIsPosNeg() == 0)
			type = "Neutral";
		else
			type = "Positive";
		JLabel posNeg = new JLabel("Reviews are Mostly " + type);
		posNeg.setBounds(31, 42, 200, 16);
		contentPane.add(posNeg);

		JLabel lblReviews = new JLabel("Reviews:" );
		lblReviews.setBounds(31, 80, 61, 16);
		contentPane.add(lblReviews);

		JList<Review> reviews = new JList<Review>(Main.getReviewList(rest));
		reviews.setCellRenderer(new NewListCellRenderer());
		JScrollPane scroll = new JScrollPane(reviews);
		scroll.setBounds(31, 102, 386, 192);
		contentPane.add(scroll);
		
		JButton flagRev = new JButton("Report Review");
		flagRev.setBounds(31, 304, 120, 29);
		flagRev.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Main.hideReview(reviews.getSelectedValue());
				newui.refresh();
				ReadWindow.this.dispose();
			}
		});
		contentPane.add(flagRev);
	}
	
	private class NewListCellRenderer extends DefaultListCellRenderer {

		private static final long serialVersionUID = 16L;

		@Override
        public Component getListCellRendererComponent(
                JList list, Object value, int index,
                boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            Review label = (Review) value;
            String author = label.getAuthor().getUsername();
            String rev = label.getReview();
            String labelText = "<html>User: " + author + "<br/>Overall: " + ((Review) value).getOverallRating() + "<br/>Price: " + ((Review) value).getPriceRating() + "<br/>Review: " + rev + "<br/>---------------------------------------";
            setText(labelText);

            return this;
        }

    }
}
