package Function;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;

public class Main 
{
	private static LinkedList<User> users;
	private static LinkedList<Restaurant> restaurants;
	private static User currentUser;
	
	static File userFile = new File("userData.txt");
	static File restFile = new File("restaurantData.txt");
	
	public static void main(String[] args)
	{
		loadFromFile();
		
		if(users == null)
		{
			users = new LinkedList<User>();
		}
		if(restaurants == null)
		{
			restaurants = new LinkedList<Restaurant>();
		}
		
		if(users.isEmpty())
		{
			users.add(new User("anon", ""));
			users.add(new Admin("admin", "password"));
			currentUser = users.getFirst();
		}
		else
		{
			currentUser = users.getFirst();
			if(!verifyUser("anon", ""))
			{
				users.add(new User("anon", ""));
			}
			if(!verifyUser("admin", "password"))
			{
				users.add(new Admin("admin", "password"));
			}
		}
		verifyUser("anon", "");
		
		Restaurant[] rests = getRestaurants();
		userInterface.NEW_UI.main(args, rests);
	}
	
	// A Login Method
	public static boolean verifyUser(String name, String pass)
	{
		User user = currentUser.verifyUser(name, pass, users);
		if(user == null)
			return false;
		else
			currentUser = user;
		return true;
				
	}
	
	public static Restaurant[] search(String term, int type)
	{
		return currentUser.search(term, type, restaurants);
	}
	
	// Data Mining
	public static int retrPosNeg(Restaurant rest)
	{
		if(currentUser instanceof Admin)
		{
			return ((Admin)currentUser).mineReviewsPosNeg(rest);
		}
		return 0;
	}	
	/* To add later
	public static Review[] findOutliers(Restaurant rest)
	{
		LinkedList<Review> reviews = rest.getReviews();
		
	}
	*/
	
	// User Manipulation
	public static void addUser(User user)
	{
		currentUser.addUser(user, users);
		currentUser = user;
	}
	public static boolean removeUser(User user)
	{
		if(currentUser instanceof Admin && !(currentUser.equals(user)))
		{
			((Admin)currentUser).removeUser(user, users);
			return true;
		}
		return false;
	}
	public static void adminUser(User user)
	{
		if(currentUser instanceof Admin && !(currentUser.equals(user))  && !(user.getUsername().equals("anon")))
		{
			((Admin)currentUser).grantAdmin(user);
		}
	}
	
	// Review Manipulation
	public static void addReview(Review rev)
	{
		restaurants.get(findRest(rev.getRestaurant())).addReview(rev);
	}
	public static boolean deleteReview(Review review)
	{
		if(currentUser instanceof Admin)
		{
			((Admin)currentUser).deleteReview(review);
			return true;
		}
		return false;
	}
	public static boolean hideReview(Review review, boolean isHidden)
	{
		if(currentUser instanceof Admin)
		{
			((Admin)currentUser).hideReview(review, isHidden);
			return true;
		}
		return false;
	}
	public static Review[] getReviewList(Restaurant rest)
	{
		return rest.getReviewsArray();
	}
	
	// Restaurant Manipulation
	public static boolean addRestaurant(String name)
	{
		if(currentUser instanceof Admin)
		{
			((Admin)currentUser).addRestaurant(name, restaurants);
			return true;
		}
		return false;
	}
	public static boolean removeRestaurant(Restaurant rest)
	{
		if(currentUser instanceof Admin)
		{
			((Admin)currentUser).removeRestaurant(rest, restaurants);
			return true;
		}
		return false;
	}
	private static int findRest(Restaurant rest)
	{
		for(int i = 0; i < restaurants.size(); i++)
		{
			if(restaurants.get(i).getName().equals(rest.getName()))
				return i;
		}
		return -1;
	}
	
	public static Restaurant[] getRestaurants()
	{
		return restaurants.toArray(new Restaurant[restaurants.size()]);
	}
	public static User[] getUsers()
	{
		return users.toArray(new User[users.size()]);
	}
	public static User getCurrentUser()
	{
		return currentUser;
	}
	
	// Save/Load Data
	public static void saveToFile()
	{
		saveToFile(users, restaurants);
	}
	private static void saveToFile(LinkedList<User> user, LinkedList<Restaurant> rest)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream(restFile, false);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(rest);
			System.out.println("Saved Restaurants");
			
			fos = new FileOutputStream(userFile, false);
			oos = new ObjectOutputStream(fos);
			oos.writeObject(user);
			System.out.println("Saved Users");
			
			oos.close();
			fos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	private static void loadFromFile()
	{
		users = (LinkedList<User>)loadFromFile(userFile);
		restaurants = (LinkedList<Restaurant>)loadFromFile(restFile);
	}
	private static Object loadFromFile(File file)
	{
		try
		{
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);

			Object o = ois.readObject();
			
			ois.close();
			fis.close();
			
			return o;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
}
